using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace EmailSendingApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            MailMessage mail=new MailMessage("dilkaprabha@gmail.com", textBox1.Text);
            mail.Subject = textBox2.Text;
            mail.Body = textBox3.Text;
            foreach(string filename in openFileDialog1.FileNames)
            {
                if (File.Exists(filename))
                {
                    string fname = Path.GetFileName(filename);
                    mail.Attachments.Add(new Attachment(filename));
                }
            }
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            System.Net.NetworkCredential nc = new NetworkCredential("dilkaprabha@gmail.com", "vwkervnfguqkbjeq");
            smtp.EnableSsl = true;
            smtp.Credentials = nc;
            smtp.Send(mail);
            label4.Text = "Mail has been send Sucessfully " + textBox1.Text;


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.ShowDialog();
            foreach (string filename in openFileDialog1.FileNames)
            {
                MessageBox.Show(filename);
                label5.Text=filename.ToString();
            }
        }
    }
}